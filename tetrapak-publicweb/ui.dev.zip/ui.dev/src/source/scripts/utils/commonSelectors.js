import $ from 'jquery';
// Common global selectors
export const $global = $('html,body');
export const $html = $('html');
export const $document = $(document);
export const $body = $(document.body);
export const $win = $(window);