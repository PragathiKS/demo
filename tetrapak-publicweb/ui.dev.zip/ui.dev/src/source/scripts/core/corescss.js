// CSS imports from publicweb
import '../../styles/vendor.scss';
// Styles import
import '../../styles/global/default/en/base.scss';
